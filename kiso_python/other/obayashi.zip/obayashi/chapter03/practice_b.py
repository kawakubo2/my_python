year = int(input('生まれた年を入力してください: '))

if year >= 2001:
    print('21世紀生まれですね')
else:
    print('21世紀生まれではありません')