colors1 = ['yellow', 'red', 'green']
colors2 = ['黄色', '赤', '緑']

for e, j in zip(colors1, colors2):
    print("{:6}: {}".format(e, j))