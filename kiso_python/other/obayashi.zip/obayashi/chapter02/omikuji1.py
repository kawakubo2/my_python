import random

kuji = ['大吉', '中吉', '凶']

print(kuji[random.randrange(len(kuji))])