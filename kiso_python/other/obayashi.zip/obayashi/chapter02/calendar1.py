from calendar import TextCalendar

cal = TextCalendar(6)
cal.prmonth(2022, 8)