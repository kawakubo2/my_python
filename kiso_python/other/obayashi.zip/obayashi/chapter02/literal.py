n = 10
print(n)
n = 0xff
print(n)
n = 0o77
print(n)
n = 0b111111111
print(n)

x = 1.23e8

print(x)

x = 0.0000000000000000123
print(x)

print("H's teacher.")
print('He is "GREAT" teacher.')
print('He\'s \n"GREAT" \t\t\tteacher')
print("Caf\u00E9")
print("\u10DA")

print(hex(255))
print(oct(255))
print(bin(255))