cm = float(input("センチメートルを入力してください: "))
print(f"{cm:.3f}は{cm/2.54:.3f}インチです")