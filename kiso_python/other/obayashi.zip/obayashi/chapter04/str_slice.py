s = "月火水木金土日"

print(s[:3])
print(s[3:])

print("日月" in s)
print("水木" in s)